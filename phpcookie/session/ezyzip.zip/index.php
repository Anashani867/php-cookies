
<?php

require'vendor/autoload.php';
require 'functions.php';
require 'models/User.php';
require 'migrations/2024_10_22_create_products_table.php';
require 'app/Router.php';
//dd( $_SERVER['REQUEST_URI']);

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

//dd($_ENV['DB_SERVER']);
//

$server_name = 'localhost';
$database_name='php-mvc';
$username = 'root';
$password = '';

$dsn ="mysql:host=$server_name;dbname=$database_name";

try{
    $pdo =new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){
    echo 'connection failed' .$e->getMessage();
}
$newuser = new User();
//dd($newuser);
//dd( $newuser-> all());

//$routes = [
//        '/' =>'views/pages/index.view.php',
//'/pricing' => 'views/pages/pricing.view.php',
//'/products' => 'controllers/products/show-products.php',
//'/about' => 'views/pages/about.view.php',
//'/contact' => 'views/pages/contact.view.php',
//'404' => 'views/pages/404.view.php',
//    ];



//if (array_key_exists($_SERVER['REQUEST_URI'], $routes)){
//    require $routes[$_SERVER['REQUEST_URI']];
//}
//else {
//    require 'views/pages/404.view.php';
//}
//
// Usage example:

$router = new Router();

// Define routes using HTTP method functions
$router->get('/', 'PageController@index');
$router->get('/products', 'ProductController@index');
$router->post('/submit', function() {
    echo "Form submitted!";
});

// Dispatch the route based on the current request
$router->dispatch();