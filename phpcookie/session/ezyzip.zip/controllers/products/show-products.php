<?php
require 'models/Product.php';

require 'views/product.view.php';

$productModel=new Product();
$products=$productModel->all();
