<?php
require 'models/Product.php';
class ProductController
{

    public function index(){
        $productModel = new Product();
        $products = $productModel->all();
            require "views/products/show.view.php";

    }
}