<?php

class PageController{
    public function index(){

        require "views/pages/index.view.php";
    }
}