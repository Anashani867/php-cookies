<?php

class Router {
    private $routes = [];

    // Method to register a route
    public function addRoute($methods, $path, $handler) {
        $methods = is_array($methods) ? array_map('strtoupper', $methods) : [strtoupper($methods)];

        $this->routes[] = [
            'methods' => $methods,
            'path' => $path,
            'handler' => $handler
        ];
    }

    // Define the GET route
    public function get($path, $handler) {
        $this->addRoute('GET', $path, $handler);
    }

    // Define the POST route
    public function post($path, $handler) {
        $this->addRoute('POST', $path, $handler);
    }

    // Define the PUT route
    public function put($path, $handler) {
        $this->addRoute('PUT', $path, $handler);
    }

    // Define the DELETE route
    public function delete($path, $handler) {
        $this->addRoute('DELETE', $path, $handler);
    }

    // Method to dispatch the route based on the requested path and method
    public function dispatch() {
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        $requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        foreach ($this->routes as $route) {
            // Check if the request method is in the list of allowed methods and the path matches
            if (in_array($requestMethod, $route['methods']) && $requestUri === $route['path']) {
                // Check if handler is a string (Controller@method) or a closure
                if (is_string($route['handler'])) {
                    list($controller, $method) = explode('@', $route['handler']);
                    $controllerFile = 'controllers/' . $controller . '.php';

                    // Check if the controller file exists in the controllers folder
                    if (file_exists($controllerFile)) {
                        require_once $controllerFile;

                        if (class_exists($controller) && method_exists($controller, $method)) {
                            $controllerInstance = new $controller();
                            $controllerInstance->$method();
                        } else {
                            throw new Exception("Handler {$route['handler']} not found.");
                        }
                    } else {
                        throw new Exception("Controller file {$controllerFile} not found.");
                    }
                } else {
                    call_user_func($route['handler']);
                }
                return;
            }
        }

        // If no matching route is found, return a 404 response
        http_response_code(404);
        echo "404 Not Found";
    }
}

?>
