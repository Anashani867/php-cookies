<?php require 'views/partials/header.php'; ?>
<main class="container mt-4">
    <h1>404</h1>
<p>page not found</p>
<a href="/"> go back to home</a>
</main>
