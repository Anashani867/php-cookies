<?php require  'views/partials/header.php'; ?>
<main class=" container m-4">
    <h1>Pricing</h1>
</main>
<?php require  'views/partials/footer.php'; ?>