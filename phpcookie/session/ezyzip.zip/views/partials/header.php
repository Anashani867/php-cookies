<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Boosted demo</title>
    <!-- Copyright © 2014 Monotype Imaging Inc. All rights reserved -->
    <link href="https://cdn.jsdelivr.net/npm/boosted@5.3.3/dist/css/orange-helvetica.min.css" rel="stylesheet" integrity="sha384-A0Qk1uKfS1i83/YuU13i2nx5pk79PkIfNFOVzTcjCMPGKIDj9Lqx9lJmV7cdBVQZ" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/boosted@5.3.3/dist/css/boosted.min.css" rel="stylesheet" integrity="sha384-laZ3JUZ5Ln2YqhfBvadDpNyBo7w5qmWaRnnXuRwNhJeTEFuSdGbzl4ZGHAEnTozR" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                 <a class="stretched-link" href="#">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAT4AAACfCAMAAABX0UX9AAABI1BMVEX9/f31gR7////2///6/f///PXwfRf//Pv8///zgR7//Pj9/f//8tTbgS73gx3tgib8//rnhzf+8tjwt3/3fxnxgiPyu4X9fxPz/////O/6fxj/+vHvhR7/+f3pn2LohSn6fSTuv5b86M/xeQD3zqj3//f/+en/+OL/8Mnnl1X/9vH/8+P/fA3lfR/34MTpnln/5sDzkULgvKHvq2vnqW/jr3rwiTTrlkz8zIr62av60Jr/wG/6tnj0x5f73qvt2sLdiED1yKL82Zn+5Lf826XxkDjnmE/1mk3jtpLz0rLVn2zopHHgeyz35tD10br5vYTXjlHjo3nQfDDquZT02bHtey7zxI/al2XMejv4vXn5z675rFvejEzehCHVjDvXomDhhBLCcd3kAAANz0lEQVR4nO2aDVvbRraAJUsaaSRbI4sZ68sgsB0Jx5JtaoOv2bg1SwulQMO2hGxbsrf//1fcMzZOU9Le3X2G5kF55k1w7NEH0euZc85Io9QeUJ4Ga4PzPLAB8ykurPaHKE+szzbW2M8ExTSVCunbfOv6M8FxLEd5CoGfRt97f091PjF0CxRavAuK8skG70vj+QBxD/wpTxD+Po0+XeN/ng1KYteg91VGn+k9K5IssZXq6HP8VmurtfVs2PtiYCh6ZWKfU28gVKIAMfQsoA0fEof+BKn3U+lTXaIGKlOfBbQp9Qkg9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9Qkh9f03IIC/rt5/Lvoo8PhCGcMY823xw1a8asab7bzZfdzuuvCOMQZnXLdgla4asIppELODyXR6OOpOD4/U4mgyY0VReX34vZHfgdf2QAR3sv68afvTdt72oG/TvNIH9uB3Bvj8f+b14791b7MRxa/yBSNqXHF966vkV/iItR3ohWse6/uz9piqq3Ntml3+To1VQkAuQ9Nho1t++dUxW86vT9DyqKi4PnU1bPFH+vigdTeaQMAjTfiP2leiYvrB14IxP4cLJ+N7uzSY7Kek8fe90/503jtBJK66PhqvgttHsW8T2tY9ET486mUP+1D1t3bei/EmUn6g1eVtMd/TDXZOG43G19PFF8fT1z1UBNWOfWhjIX6s7304e/CBPop9KzZWMeWHMEYewgD+zR/l8RDHMd+OJuOUlLeH/c7p0eIrFjBSaX2qSlJCVqPwEQSaMbekupjBB+yqv9fHBzBvVz+QBA0pYb8bvOuRzpsxb5x8ySj6eqs8XXSPe4weVVqfi+jBaHR2npZkoxM9lGZl8+CID0XMSvLN+WxGENroWO0CSsr0/GyGEW970Ae7zs7TdWn3fn+KUHo+O2sSBN9FcwSKvzkgs2U8O2dFzCqqLw4YQ83WcJDnvt852WmyVXhCi+FweDtKR/NOfa9BA9wYLYaDQV7fH56MuGISkMtve/NRTC4vOnDs/u13ZRCrcUEJWe516rl/Pby8mgyvx6czggOsoqPLoV/f9wfXe7M2jHUY3zyRYAr9FuJuRfUxl5LJOKsptqFomjK4axIauxgNa3Yt+navHhnRXlrQ5feD6MULT9mu6Z7/mqgsLc59w4i+vV/4nq5bVmblo9hlED2v3p7mmhZaupXv/WxZST4iasHK/m1W0zTN0iyjPi3dGPOy8H35XVV9RyUUrp5thaGmg77En9+XkEDQ2IYPAw/a89fdYDZObNu2ALj+MHpdHjXoWabr3vXAU7zE8HQj9E4bKVPTeGcQJZrmZZFiD15qoO8MZhpXOx1b0z3PU2xT1wetq01ZU3F9LL3MLQvMeUlkGLbxMuv9wIIYjfXQTLQw5Pra5DgKQ/vlVz/35vUERNf7JKX9CDpTFGpRZ3ybGx7seNjEkASGmqlr+e3i1rd1faUPMvPNdaTo1qDXWgwN3Xk5+AdWVyWMWnF9tHFdg8vN5q+mhye+HYZ6Pi3jGA+10E4UPRr4+5M03blQjPEEkgE6H8IANPZi3B1F0BeNrHO4bC6/yw3olPMyDtCW4ZihMYGy7mZoKIpu5GcQ4/Y804iGN2XRXZ5khmkOUwh4HxTpVdWHp5HxMtRe0y5iV5e+FmrGbYPG+FrT7CjrbM0OmimiKL183URBEFB0YkWRddGNi1EEwzm6W4Iz/MPcMHXvtgwC1NGSRPuiC2dm953Etrg+vKwbmlY/6xZB0H03fxEq9RF8RzDXpRXXl85t+6U1OAqgog3KrdzUbb+PY3RtGZ7RuWFgjAZBEbTflW/eYNRufG9FiXVB42InsRMrajAaFLR5Z5uONS4D9xsvzMykXxSMFagVKY6dnVGyk9maNmzErJGi8s4LrbzVoJCj1bji+hr7WmgOfiQU4nuh3vi2qeRbUNJeG5mmXaSxup7TQkpF6ajVGw4TDRLIBXPjS8M0LCPlCZRdva6BvmFJy0kYRmEHOmp6VBRvIxjoWZ+WLcjOxvBwOoW/lxeJYxnzhvsZ6KM3uaLreR+KsKJN4va1burRHWJoaNmK1UOUqGpKgrh5NerV88i0tvXwheP02u14x3Bg8Ka7uM3i9qLmOLUOYmThQUScIxoQKICWvqXbWT8uj71khWEkBqRw0zE7S14isorHPrqTmbaVz9T2btE+KrpfWablHSOChpri1HpIBQmEBGjnNvdCDS48sUMN9DH2Xh/lh+55jlXrdAnuRaam90oMFbGqLuuWBvqCcq7xkk93dN2BVxP0DUFfzKqvL9I9xV/GWC0wK7oXjql5x+WH+gJMysk+ZFYrG/d+/G4IDowe+U2futGngD60iOyadVHyER+r975mgT6aznkJlOR+nkfrTph93YT8xKqeOugIwpOd30OiDFyYHNzatmYtSkI3+iAzUDLa93QvGk+bJUt7244Wzd/8mb47QzFrFykFe4Xazzf6YA4S9W7Ozs4OgHP4mREKYTWueOxTl3moGNGlqsIM1KXNsQGD946w972PqUFQQtWsZPMlxMcCzf9/fQsPhnjnis9+CzyBityOIHUcQ0Ge35VBtw21CmaoCNjqViutur50rHmGd3IFc/ddNX3rG6YSTdFv+rBK4+bYCvXsuwZGkEd6tqMZvT/VN7VCw8z6SI0DerWIVvpithVBWTiEZNs+Yog0Uuj2/MbX+7FbWX2sZ9l2OLh/47q7rPF9ZCmGvwww2+hTYRTOfJgPZ2+Jy9L0nxeRBxug9Q/10WamRZbWazDMGpc+RALQV7ij3ITY95YwQougfPUKqsXVzS3MKq4Pva0ZdvhiftDt7rKfBkqoRBdpoZIHfS5kUAr6bD2bdAMXkR8HUeQ4P+OP9Ck6z7yUXhgwVc7uDtKDrQ6847GviBtQLobG/AhBJy+3/KwzdTHmTz5IxfXhq17Ek2rn4uTncW47obc/QoFKxlDo2r1Gm99Pbo7tcPvlcHq20xqbjvHCi07euOll4uhKzjDBQdDYg6mIN0aUob4fQjT1cn+QeJrOq6J+TNUR7KxF49Zk53BoQHP9l5KpMWVV730q6489TVNM27Oh3VLyVgpzAQz6nGiRBhQu8uou43egfH9gb0PRpoVeryzQTg4fuD4VetedZ4XauIQaEb3KNMWwNN1xjOSlaUNNTmF+1ssNfo48g6rFtmvDZspc/oSk6vpoujPO4Np5Zabpnt/6IVV3VTSET0mv4fJHjuT+Nn8RalZt29mu1w09VObv4vIyd8LwBVnpu2pZGtcH87AYtfLMsMJQT/a/HWwrGuiDJPuvv8OBoBSqRiXxezcw4aBx9e/3YeqWs4UPPUKxrCgfTlKyWpMx9jwjnzfY6tnYVf8YxrVjZvtf/u+0npj5cdpOp/XI8yKi8kFY/hRlWXTKYtYmaWP0te9lRnI7uvEda6WP4fa7rXFmb5tRYkTDrSbDiH54w6+q+nhdF5c7e7fj/fF4MVny8o/PBn6ZAOd8BxrHLG1e7l1c/Dj9169l85eftqbnLIiPRnwXvFq/Qs63JpNDCJrYbRPIDjeHk8u3Tbas66BvRvlvUdPl9G5+eztv9ZsEMkgcfw76+L2CIGblVXPZbJYoBpmgD7uUIsYQH18ufwbOXMTKN2w3iOP2r7+28S5fhMG70PqeO2MEQiS/Wxq7QUFLVsDRFJ35uq75zYAyGOCQJ8p22bwia3XrxQtVr/sIVxWvV0KtH5Ovlves1ruQ9UPe1SoDft/Ppbu7MZ+cgDu+jbR55uQeYSpRFKAwwGpzOWotZgX/Ht7dRbppdZpFjB+WMbj8PgFhUPw9WpNUVX3M5Zb4My+XdyjuhK8ua/MVFXH8sPgCru/Nm9UqIAhiDByqbV70cngC4JMvEhTkiIKbUw8Y9kvULV/VPc1RLkouq93ma434qqs44AuF1itjqj/rUD9cM/D+/UerDfBmGdBmwd7j7evuhK/uckjjdt4ZdgYez+adPoxw3i03Z1E3C2I+PLy6+p4WspxnFkzVeHVn20aST8kq/fybw6S+Bw/kvpdHhgJlo5Vk+XiHBAGGaCf1/UdAXFte9sZ+kkR5p3d4wyDUsc9Sn/qX9D6IbOXV8n42mzWPGF/4htsww/gMB+9fog+KOihZqFpANckfcK5yOZax7z/Vh+l6QrEqgqA6YVAJ/a5C/kz0IVSiADH0xGD8sFAc/kGIdinqdruY/LvDGtXS57fuWndA63mw98XAUMBeRfTBf3SN4j0LkiyxHUuxq6JvtfYMXrTngZLYil4hfd4LI/KMZwN40y29Ovq2NzzR+QQBdzr0vsrEPucB/XlgOY7lKE+QeD/Z4F3j2c8BGLzQ8Z5A3qfSt+l+T3U6UbjEv1Df/wHHV5gYYszbpwAAAABJRU5ErkJggg==" width="50" height="50" alt="Boosted - Back to Home" loading="lazy">
                </a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pricing">Pricing</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
