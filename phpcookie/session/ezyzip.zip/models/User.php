<?php
require_once __DIR__ . "/Model.php";
//namespace models;

// Make sure to include the Model class in your autoload
class User extends Model
{
    public function __construct()
    {
        parent::__construct('users');
    }
}

