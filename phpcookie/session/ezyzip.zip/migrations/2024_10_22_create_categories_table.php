<?php

//namespace migrations;


class CreateCategoriesTable
{
    public function up()
    {
        return "CREATE TABLE categories (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,  -- Make it a primary key
            name VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";  // Specify storage engine
    }

    public function down()
    {
        return "DROP TABLE IF EXISTS categories";  // Use IF EXISTS to avoid errors
    }
}