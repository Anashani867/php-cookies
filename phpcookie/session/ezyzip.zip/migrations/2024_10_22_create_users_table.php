<?php
class CreateUsersTable
{
    public function up()
    {
        return "CREATE TABLE IF NOT EXISTS users (
id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(255) NOT NULL,
email VARCHAR(255) NOT NULL UNIQUE,  -- Add UNIQUE constraint for email
password VARCHAR(255) NOT NULL,
created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB";  // Specify storage engine
    }

    public function down()
    {
        return "DROP TABLE IF EXISTS users";  // Use IF EXISTS to avoid errors
    }
}