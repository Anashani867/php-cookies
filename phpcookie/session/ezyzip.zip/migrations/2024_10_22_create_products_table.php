<?php


class CreateProductsTable
{
    public function up()
    {
        return "CREATE TABLE products (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,  -- Use INT and make it a primary key
            name VARCHAR(255) NOT NULL,
            price INT NOT NULL,  -- Use INT for price
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";  // Specify storage engine
    }

    public function down()
    {
        return "DROP TABLE IF EXISTS products";  // Use IF EXISTS to avoid errors
    }
}