<?php
// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$dbname = "php-mvc";
$dsn = 'mysql:host=' . $host . ';dbname=' . $dbname;

try {
    // Create a new PDO instance
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Fetch executed migrations from the database
$executedMigrations = $pdo->query("SELECT migration FROM migrations")->fetchAll(PDO::FETCH_COLUMN);
$migrationFiles = scandir(__DIR__ . '/migrations'); // Scan the migrations directory

// Determine the next batch number
$batch = (int)$pdo->query("SELECT MAX(batch) FROM migrations")->fetchColumn() + 1;

// Process each migration file
foreach ($migrationFiles as $file) {
    // Skip current and parent directory references
    if ($file === "." || $file === "..") {
        continue;
    }

    $className = convertToClassName($file);

    // Check if the migration has already been executed
    if (!in_array($file, $executedMigrations)) {
        require __DIR__ . '/migrations/' . $file; // Include the migration file

        if (class_exists($className)) {
            $migration = new $className();
            $sql = $migration->up(); // Get the SQL statement from the up method

            // Execute the SQL statement
            try {
                $pdo->exec($sql);

                // Insert into migrations table after running the migration
                $stmt = $pdo->prepare("INSERT INTO migrations (migration, batch) VALUES (?, ?)");
                $stmt->execute([$file, $batch]);
            } catch (PDOException $e) {
                echo "Error running migration: " . $e->getMessage() . "\n";
            }
        } else {
            echo "Class $className not found in file $file\n";
        }
    } else {
        echo "Migration $file has already been executed.\n";
    }
}

/**
 * Convert a migration file name to a class name.
 *
 * @param string $file The migration file name.
 * @return string The corresponding class name.
 */
function convertToClassName($file) {
    // Remove the date and file extension
    $fileNameWithoutDate = preg_replace('/^\d{4}_\d{2}_\d{2}_/', '', pathinfo($file, PATHINFO_FILENAME)); // Removes YYYY_MM_DD_

    // Split the filename by underscores
    $parts = explode('_', $fileNameWithoutDate);

    $className = '';
    foreach ($parts as $part) {
        $className .= ucfirst($part); // Capitalize the first character of each part
    }

    return $className; // Return the constructed class name
}